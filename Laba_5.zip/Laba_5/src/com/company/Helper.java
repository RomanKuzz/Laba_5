package com.company;

import java.util.*;

public class Helper implements RandGen{

        private List<Reader> studentList;
        private List<Reader> teacherList;

        //

        public void generate(int readersNumber){
                int studentsNumber = getRandomIntegerIncludingEdge(readersNumber);
                int teacherNumber = readersNumber - studentsNumber;
                //
                ReaderGen generatorStudent = new StudentGen();
                ReaderGen generatorProfessor = new TeacherGen();
                //
                generatorStudent.generate(studentsNumber);
                generatorProfessor.generate(teacherNumber);
                //
                HashSet<Reader> students = generatorStudent.convert();
                studentList = new ArrayList<>(students);
                HashSet<Reader> professors = generatorProfessor.convert();
                teacherList =new ArrayList<>(professors);
                //

        }



        public List<Reader> getStudentList() {
                return studentList;
        }

        public List<Reader> getProfessorList() {
                return teacherList;
        }
}