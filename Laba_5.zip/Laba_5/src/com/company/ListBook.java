package com.company;

import java.util.HashSet;

public class ListBook{

    private HashSet<Reader> students;
    private HashSet<Reader>teachers;

    public ListBook(){
        this.students = new HashSet<>();
        this.teachers = new HashSet<>();
    }

    public void setStudents(HashSet<Reader> students) {
        this.students = students;
    }

    public void setTeachers(HashSet<Reader> teachers) {
        this.teachers = teachers;
    }




    @Override
    public String toString() {
        return "ListBook{" +
                "\nstudents=" + students +
                "\n, teachers=" + teachers +
                '}';
    }
}