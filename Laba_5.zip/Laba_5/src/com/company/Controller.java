package com.company;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.List;

public class Controller {
    private TreeView<String> treeView = new TreeView<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        TextArea textAreaImp = new TextArea();
        textAreaImp.setEditable(false);
        Group groupTextAreaImp = new Group(textAreaImp);
        textAreaImp.setPrefSize(300, 20);
        Button buttonImpDir = new Button("...");
        buttonImpDir.setPrefSize(30, 37);
        buttonImpDir.setOnAction(actionEvent -> {
            textAreaImp.clear();
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                textAreaImp.appendText(file.getAbsolutePath());
            }
        });
        Group groupButtonImpDir = new Group(buttonImpDir);
        Button buttonImp = new Button("Загрузка");
        buttonImp.setPrefSize(80, 37);
        buttonImp.setOnAction(actionEvent -> {

            try {
                Parser parser = new Parser(textAreaImp.getText());
                parser.parse();

                Helper helper = new Helper();
                Helper.generate(5);
                createTreeView(controller.getStudentList());

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("внимание");
                alert.setHeaderText(null);
                alert.setContentText("готово");
                alert.showAndWait();
            } catch (Exception exception) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Warning!!!");
                alert.setHeaderText(null);
                alert.setContentText("ошибка");
                alert.showAndWait();
                exception.printStackTrace();
            }
        });
        Group groupButtonImp = new Group(buttonImp);
        treeView = new TreeView<>();
        treeView.setPrefSize(850, 500);
        HBox treeHBox = new HBox();
        treeHBox.getChildren().addAll(treeView);


        HBox importChild = new HBox(groupButtonImpDir, groupTextAreaImp, groupButtonImp);
        VBox root = new VBox(importChild, treeHBox);
        Scene scene = new Scene(root, 850, 550);
        primaryStage.setScene(scene);
        primaryStage.setTitle("действие");
        primaryStage.setResizable(false);
        primaryStage.show();

    }

    public void createTreeView(List<Reader> readerList) {
        TreeItem<String> rootItem = new TreeItem<>("добавления");
        for (Reader reader : readerList) {
            TreeItem<String> branchItem = new TreeItem<>(reader.getLastName());
            for (Book book : reader.getBooks()) {
                TreeItem<String> leafItem = new TreeItem<>(book.getAuthor() + " " + book.getTitle());
                branchItem.getChildren().add(leafItem);
            }
            rootItem.getChildren().add(branchItem);
        }

        treeView.setRoot(rootItem);
        treeView.setShowRoot(true);
    }
}

