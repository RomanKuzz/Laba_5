package com.company;

import java.util.ArrayList;
import java.util.HashSet;

public interface ReaderGen extends RandGen, Generator {

    default void generate(int readersNumber){
        generateWithBooks(readersNumber, new BooksNumber(0,0,0));
    }

    default void generateWithBooks(int readersNumber, BooksNumber booksNumber){
        for(int i=1; i<=readersNumber; i++){
            generateWithBooks(booksNumber);
        }
    }

    default void generateWithBooks(BooksNumber booksNumber){
        Reader reader = (Reader) generate();
        addNew(reader);
        //
        FictionGen fictionGen = new FictionGen();
        RusEdGen rusedgen = new RusEdGen();
        EngEdGen engedgen = new EngEdGen();
        //
        fictionGen.generate(booksNumber.getFictions());
        rusedgen.generate(booksNumber.getRusEd());
        engedgen.generate(booksNumber.getEngEd());
        //
        reader.addBooks(fictionGen.convert());
        reader.addBooks(rusedgen.convert());
        reader.addBooks(engedgen.convert());
    }

    default void generateWithBooks(int readersNumber, int booksNumber){
        for(int i=1; i<=readersNumber; i++){
            int fictionsNumber = getRandomIntegerIncludingEdge(booksNumber);
            int rusEdNumber = getRandomIntegerIncludingEdge(booksNumber-fictionsNumber);
            int engEdNumber = booksNumber-(fictionsNumber+rusEdNumber);
            generateWithBooks(new BooksNumber(fictionsNumber, rusEdNumber, engEdNumber));
        }
    }

    @Override
    default void addNew(Object reader){
        get().add(reader);
    }

    default Reader convert(Object reader){
        return (Reader) reader;
    }

    default HashSet<Reader> convert(){
        HashSet<Object> readers = get();
        HashSet<Reader> readersConverted = new HashSet<>();
        for(Object reader : readers){
            readersConverted.add(convert(reader));
        }
        return readersConverted;
    }

    // GET

    ArrayList<String> getFirstNames();

    ArrayList<String> getLastNames();

    default String getCorrectLastName(String firstName, String lastName){
        if(!isMale(firstName)) return lastName+"а";
        return lastName;
    }

    default String getSecondName(String firstName){
        String secondName = getRandomMaleName();
        if(secondName.endsWith("й")) secondName = secondName.substring(0, secondName.length()-1)+"е";
        else secondName += "о";
        if(isMale(firstName)) secondName += "вич";
        else secondName += "вна";
        return secondName;
    }

    default String getRandomMaleName(){
        ArrayList<String> firstNames = getFirstNames();
        while(true){
            String firstName = firstNames.get((int)(Math.random()*firstNames.size()));
            if(isMale(firstName)) return firstName;
        }
    }

    default boolean isMale(String firstName){
        return Reader.isMale(firstName);
    }

}
