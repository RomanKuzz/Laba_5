package com.company;

import java.util.ArrayList;
import java.util.HashSet;

public class RusEdGen implements BookGen{

        private HashSet<Object> rused;

        public HashSet<Object> get() {
            return rused;
        }

        public RusEdGen(){
            this.rused = new HashSet<>();
        }

        @Override
        public String[] generateArguments(){
            ArrayList<String> authors = getAuthors();
            ArrayList<String> titles = getTitles();
            ArrayList<String> disciplines = getDisciplines();
            ArrayList<String> types = getTypes();
            // all indexes are random comparing to each other
            String author = authors.get(getRandomIndex(authors));
            String title = titles.get(getRandomIndex(titles));
            String discipline = disciplines.get(getRandomIndex(disciplines));
            String type = types.get(getRandomIndex(types));
            return new String[]{author, title, discipline, type};
        }

        @Override
        public Book generate(String[] args){
            return new RusEd(args[0], args[1], args[2], args[3]);
        }

        public ArrayList<String> getAuthors(){
            return RusEdParser.getAuthors();
        }

        public ArrayList<String> getTitles(){
            return RusEdParser.getTitles();
        }

        public ArrayList<String> getDisciplines(){
            return RusEdParser.getDisciplines();
        }

        public ArrayList<String> getTypes(){
            return RusEdParser.getTypes();
        }

    }
