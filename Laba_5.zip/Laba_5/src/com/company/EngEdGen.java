package com.company;

import java.util.ArrayList;
import java.util.HashSet;

public class EngEdGen implements BookGen{

    private HashSet<Object> enged;

    public HashSet<Object> get() {
        return enged;
    }

    public EngEdGen(){
        this.enged = new HashSet<>();
    }

    @Override
    public String[] generateArguments(){
        ArrayList<String> authors = getAuthors();
        ArrayList<String> titles = getTitles();
        ArrayList<String> disciplines = getDisciplines();
        ArrayList<String> levels = getLevels();
        ArrayList<String> universities = getUniversities();
        // all indexes are random comparing to each other
        String author = authors.get(getRandomIndex(authors));
        String title = titles.get(getRandomIndex(titles));
        String discipline = disciplines.get(getRandomIndex(disciplines));
        String level = levels.get(getRandomIndex(levels));
        String university = universities.get(getRandomIndex(universities));
        return new String[]{author, title, discipline, level, university};
    }

    @Override
    public Book generate(String[] args){
        return new EngEd(args[0], args[1], args[2], args[3], args[4]);
    }

    public ArrayList<String> getAuthors(){
        return EngEdParser.getAuthors();
    }

    public ArrayList<String> getTitles(){
        return EngEdParser.getTitles();
    }

    public ArrayList<String> getDisciplines(){
        return EngEdParser.getDisciplines();
    }

    public ArrayList<String> getLevels(){
        return EngEdParser.getLevels();
    }

    public ArrayList<String> getUniversities(){
        return EngEdParser.getUniversities();
    }

}