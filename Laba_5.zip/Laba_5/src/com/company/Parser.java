package com.company;

import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Parser{


    private final String pathToFile;

    public String getPathToFile() {
        return pathToFile;
    }

    public Parser(String pathToFile){
        this.pathToFile = pathToFile;
    }

    //

    public void parse(){
        try{
            parseStudent();
            parseTeacher();
            parseFiction();
            parseRusEd();
            parseEngEd();
        } catch(IOException e){
            throw new RuntimeException(e.getMessage());
        }
    }

    public void parseStudent() throws IOException{
        StudentParser.parseSheet(getSheetByName(getWorkbook(), "student"));
    }

    public void parseTeacher() throws IOException{
        getWorkbook();
        XSSFSheet sheet = getSheetByName(getWorkbook(), "teacher");
        TeacherParser.parseSheet(getSheetByName(getWorkbook(), "teacher"));
    }

    public void parseFiction() throws IOException{
        FictionParser.parseSheet(getSheetByName(getWorkbook(), "fiction"));
    }

    public void parseRusEd() throws IOException{
        RusEdParser.parseSheet(getSheetByName(getWorkbook(), "rused"));
    }

    public void parseEngEd() throws IOException{
        EngEdParser.parseSheet(getSheetByName(getWorkbook(), "enged"));
    }


    public XSSFWorkbook getWorkbook()  throws IOException{
        XSSFWorkbook workbook = new XSSFWorkbook(getPathToFile());
     workbook.close();
     return workbook;
    }


    public XSSFSheet getSheetByName(XSSFWorkbook workbook, String sheetName){
        return workbook.getSheet(sheetName);
    }

    public static int getRowsNumberAtColumn(XSSFSheet sheet, int columnId){
        int rowsAtColumnNumber = 0;
        Iterator<?> rows = sheet.rowIterator();
        rows.next(); //header
        while(rows.hasNext()){
            XSSFRow row = (XSSFRow) rows.next();
            if(row.getCell(columnId) == null) break;
            rowsAtColumnNumber++;
        }
        return rowsAtColumnNumber;
    }

    public static int getColumnsNumber(XSSFSheet sheet) {
        int columnsNumber = 0;
        Iterator<?> rows = sheet.rowIterator();
        XSSFRow row = (XSSFRow) rows.next();
        Iterator<?> cells = row.cellIterator();
        while (cells.hasNext()) {
            columnsNumber++;
            cells.next();
        }
        return columnsNumber;
    }

}
