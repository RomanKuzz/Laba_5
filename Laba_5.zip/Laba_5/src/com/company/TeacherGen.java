package com.company;

import java.util.ArrayList;
import java.util.HashSet;

public class TeacherGen implements ReaderGen{

    private HashSet<Object> teachers;

    public HashSet<Object> get() {
        return teachers;
    }

    public TeacherGen(){
        this.teachers = new HashSet<>();
    }

    @Override
    public String[] generateArguments(){
        ArrayList<String> firstNames = getFirstNames();
        ArrayList<String> lastNames = getLastNames();
        // all indexes are random comparing to each other
        String firstName = firstNames.get(getRandomIndex(firstNames));
        String lastName = getCorrectLastName(firstName, lastNames.get(getRandomIndex(lastNames)));
        String secondName = getSecondName(firstName);
        return new String[]{firstName, secondName, lastName};
    }

    @Override
    public Reader generate(String[] args){
        return new Teacher(args[0], args[1], args[2]);
    }

    @Override
    public ArrayList<String> getFirstNames(){
        return TeacherParser.getFirstNames();
    }

    @Override
    public ArrayList<String> getLastNames(){
        return TeacherParser.getLastNames();
    }

}
