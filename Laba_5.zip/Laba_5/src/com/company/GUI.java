package com.company;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GUI extends JFrame {
    private JButton b = new JButton("import");
    private JFileChooser bb = new JFileChooser();
    private JTree jTree = new JTree(new DefaultMutableTreeNode());

    public GUI () {
        super("wow");
        this.setBounds(100, 100, 200, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container container = this.getContentPane();
        container.setLayout(new GridLayout(3, 2 ,2 ,2));
    }

    public void writeTree(JTree t, ArrayList<Reader> readers, ArrayList<Book> books) {
        DefaultTreeModel tr = (DefaultTreeModel) t.getModel();
        DefaultMutableTreeNode root = (DefaultMutableTreeNode) t.getSelectionPath().getLastPathComponent();
        DefaultMutableTreeNode teachers = new DefaultMutableTreeNode("Преподаватели");
        root.add(teachers);
        DefaultMutableTreeNode students = new DefaultMutableTreeNode("Студенты");
        root.add(students);
        int k;
        for (int i = 0; i < readers.size(); i++) {
            if (readers.get(i) instanceof Teacher) {
                DefaultMutableTreeNode y = new DefaultMutableTreeNode(readers.get(i).getLastName() + " " + readers.get(i).getFirstName()
                        + " " + ((Teacher) readers.get(i)).getSecondName() + " - ");
                teachers.add(y);
                k = (int) (Math.random() * 8 + 3);
                ChooseBook(books, y, k);
            }
            if (readers.get(i) instanceof Student) {
                DefaultMutableTreeNode y = new DefaultMutableTreeNode(readers.get(i).getLastName() + " " + readers.get(i).getFirstName());
                students.add(y);
                k = (int) (Math.random() * 8 + 3);
                ChooseBook(books, y, k);
            }
        }
        tr.reload();
    }

    public void ChooseBook(ArrayList<Book> books, DefaultMutableTreeNode y, int k) {
        int n;
        ArrayList<Integer> a = new ArrayList<Integer>();
        for (int j = 0; j < k; j++) {
            n = (int) (Math.random() * books.size());
            if (a.contains(n)) {
                n = (int) (Math.random() * books.size());
            } else {
                DefaultMutableTreeNode z = null;
                DefaultMutableTreeNode l = null;
                DefaultMutableTreeNode c = null;
                DefaultMutableTreeNode d = null;
                if (books.get(n) instanceof EngEd) {
                    z = new DefaultMutableTreeNode(getNameEng((EngEd) books.get(n)));
                    l = new DefaultMutableTreeNode(((EngEd) books.get(n)).getAuthor());
                    c = new DefaultMutableTreeNode(((EngEd) books.get(n)).getLevel());
                    d = new DefaultMutableTreeNode(((EngEd) books.get(n)).getUniversity());
                    z.add(l);
                    z.add(c);
                    z.add(d);
                }
                if (books.get(n) instanceof RusEd) {
                    z = new DefaultMutableTreeNode(getNameRus((RusEd) books.get(n)));
                }
                if (books.get(n) instanceof Fiction) {
                    z = new DefaultMutableTreeNode(getNameFiction(books.get(n)));
                }
                a.add(n);
                y.add(z);
            }
        }
    }

    public String getNameEng(EngEd book) {
        String s = "";
        s += book.getDiscipline() + ". " + book.getTitle();
        return s;
    }

    public String getNameRus(RusEd book) {
        String s = "";
        s += book.getType() + " - " + book.getDiscipline() + ". " + book.getTitle();
        return s;
    }

    public String getNameFiction(Book book) {
        String s = "";
        s += book.getTitle();
        return s;
    }

}
