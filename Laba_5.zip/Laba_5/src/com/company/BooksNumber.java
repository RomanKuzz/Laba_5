package com.company;

public class BooksNumber {

    private int fictions;
    private int rused;
    private int enged;

    public BooksNumber(int fictions, int rused, int enged) {
        this.fictions = fictions;
        this.rused = rused;
        this.enged = enged;
    }

    public int getFictions() {
        return fictions;
    }

    public int getRusEd() {
        return rused;
    }

    public int getEngEd() {
        return enged;
    }

}