package com.company;

import java.util.ArrayList;

public interface RandGen {
    default int getRandomIndex(ArrayList<?> list){
        return getRandomInteger(list.size());
    }

    default int getRandomInteger(int edge){
        return (int)(Math.random()*edge);
    }

    default int getRandomIntegerIncludingEdge(int edge){
        return getRandomInteger(edge+1);
    }
}
