package com.company;

public class Education extends Book {
    private final String discipline;

    public Education(String author, String title, String discipline){
        super(author, title);
        this.discipline = discipline;
    }

    public String getDiscipline() {
        return discipline;
    }
}
