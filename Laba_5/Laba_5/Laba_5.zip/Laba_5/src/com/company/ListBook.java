package com.company;

import java.util.HashSet;

public class ListBook{

    private HashSet<Reader> students;
    private HashSet<Reader>teachers;

    public ListBook(){
        this.students = new HashSet<>();
        this.teachers = new HashSet<>();
    }

    public HashSet<Reader> getStudents() {
        return students;
    }

    public void setStudents(HashSet<Reader> students) {
        this.students = students;
    }

    public HashSet<Reader> getTeachers() {
        return teachers;
    }

    public void setTeachers(HashSet<Reader> professors) {
        this.teachers = professors;
    }

    //

    public void addStudent(Reader student){
        getStudents().add(student);
    }

    public void addTeachers(Reader teachers){
        getTeachers().add(teachers);
    }

    //

    public void removeStudent(Reader student){
        getStudents().remove(student);
    }

    public void removeTeachers(Reader teachers){
        getTeachers().remove(teachers);
    }

    //


    @Override
    public String toString() {
        return "ListBook{" +
                "\nstudents=" + students +
                "\n, teachers=" + teachers +
                '}';
    }
}