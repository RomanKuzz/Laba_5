package com.company;

public class Teacher extends Reader{
    private final String secondName;

    public Teacher(String firstName, String secondName, String lastName){
        super(firstName, lastName);
        this.secondName = secondName;
    }

    public String getSecondName() {
        return secondName;
    }

    @Override
    public String toString(){
        return "\nTeacher{" +
                "firstName='" + getFirstName() + '\'' +
                ", secondName='" + getSecondName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", \n\tbooks=" + getBooks() +
                '}';
    }

}
