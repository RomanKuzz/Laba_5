package com.company;

public class Controller {
    public static void main(String[] args){
        Parser parser = new Parser("C:\\Users\\Roman\\Desktop\\library.xlsx");
        parser.parse();

        Generator generatorBook = new EngEdGen();
        generatorBook.generate(2);
        ReaderGen generatorStudent = new StudentGen();
        generatorStudent.generateWithBooks(2, 6);
        ReaderGen generatorTeacher = new TeacherGen();
        generatorTeacher.generateWithBooks(3, 3);

        ListBook listbook = new ListBook();
        listbook.setStudents(generatorStudent.convert());
        listbook.setTeachers(generatorTeacher.convert());
        System.out.println(listbook);
    }
}
