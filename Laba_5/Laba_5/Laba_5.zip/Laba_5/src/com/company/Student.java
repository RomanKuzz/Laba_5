package com.company;

public class Student extends Reader {

    public Student(String firstName, String lastName){
        super(firstName, lastName);
    }

    @Override
    public String toString(){
        return "\nStudent{" +
                "firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", \n\tbooks=" + getBooks() +
                '}';
    }

}
