package com.company;

public class RusEd extends Education {

    private final String type;

    public RusEd(String author, String title, String discipline, String type){
        super(author, title, discipline);
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return "\n\tRusEd{" +
                "author='" + getAuthor() + '\'' +
                ", title='" + getTitle() + '\'' +
                ", discipline='" + getDiscipline() + '\'' +
                ", type='" + getType() + '\'' +
                '}';
    }

}